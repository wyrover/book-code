//std.h

#include <windows.h>

#include "data.h"
#include "myservice.h"
#include "servicehandler.h"