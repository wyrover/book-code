//servicehandler.h

unsigned long WINAPI MyServiceHandler( DWORD fdwControl, DWORD dwEventType,
							  LPVOID lpEventData, LPVOID lpContext);

void MySetStatus(DWORD dwState, DWORD dwAccept=SERVICE_ACCEPT_STOP | SERVICE_ACCEPT_PAUSE_CONTINUE);
