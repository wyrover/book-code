//servicehandler.h

void MyServiceHandler(DWORD fdwControl);

void MySetStatus(DWORD dwState, DWORD dwAccept=SERVICE_ACCEPT_STOP | SERVICE_ACCEPT_PAUSE_CONTINUE);
