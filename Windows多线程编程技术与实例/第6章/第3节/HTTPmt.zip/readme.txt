HTTPMT	Multi-threaded HTTP server that uses blocking sockets, overlapped
		I/O and client threads to handle multiple simultaneous connections.
