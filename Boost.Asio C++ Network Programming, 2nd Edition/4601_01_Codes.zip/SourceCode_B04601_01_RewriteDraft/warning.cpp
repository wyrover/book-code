/* warning.cpp */ 
#include <iostream>
#include <string>
int main (void)
{
	std::string name;
	int age;
	std::cout << "Hi " << name << ", your age is " << age << "\n ";
}