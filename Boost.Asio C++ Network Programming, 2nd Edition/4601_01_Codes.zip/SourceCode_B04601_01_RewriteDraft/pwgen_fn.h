/* pwgen_fn.h */
#include <string>
#include <cstdlib>
#include <ctime>
class PasswordGenerator
{
public:
	std::string Generate(int);
}; 